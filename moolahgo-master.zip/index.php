<?php
/**
 * Main index file.
 * 
 * This is the main index file
 * 
 * @author Robin Correa <robin.correa21@gmail.com>
 */
require_once 'application/initialize.php';
$application = new Application;
?>
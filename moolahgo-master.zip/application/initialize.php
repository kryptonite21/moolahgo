<?php
/**
 * Initialization file
 * 
 * It will require all the core components needed.
 * 
 * @author Robin Correa <robin.correa21@gmail.com>
 */
require_once 'core/Application.php';
require_once 'core/Controller.php';
?>
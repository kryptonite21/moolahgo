<div class="container">
  <form action="#" class="form-signin" method="post" accept-charset="utf-8">
  <img class="img img-responsive form-signin" src="<?php echo BASE_URL; ?>/public/logo/login_logo.png" width="300px" alt="Login Logo">

  <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
  <input type="password" class="form-control" name="password" placeholder="Password" required>

  <input type="submit" class="btn btn-lg btn-success btn-block" name="btn_submit" value="Sign in">
</form>  

</div>
<link href="<?php echo BASE_URL; ?>/public/css/signin.css" rel="stylesheet">

<body>

<div class="container">
    <div class="jumbotron">
    <p><img class="img img-responsive form-signin" src="<?php echo BASE_URL; ?>/public/logo/login_logo.png" width="250px" alt="Login Logo"></p>
    <h2>How it works</h2>
    <p>MoolahGo is an innovative Marketplace technology platform. Our Marketplace allows our members to transact based on 2 service models:
        <ul>
            <li>Peer-to-Peer (P2P) or Express</li>
            <li>Express service</li>
        </ul>
    </p>
    <p><a class="btn btn-success btn-md" href="#" role="button">Learn more</a></p>
    </div>
    
</div>





</body>
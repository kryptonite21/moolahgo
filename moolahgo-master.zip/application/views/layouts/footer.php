<footer>
    <hr />
<p class="text-center">Copyright &copy; <?php echo date('Y') ?> Moolahgo | Calculator</p>
<p class="text-center">Powered by <strong>Robin Correa</strong></p>
</footer>
</body>

</html>